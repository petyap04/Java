package bg.sofia.uni.fmi.mjt.vehiclerent.exception;

public final class IllegalArgumentException extends MyException{

    IllegalArgumentException() {
        super("Invalid Argument");
    }

}
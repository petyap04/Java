package bg.sofia.uni.fmi.mjt.vehiclerent.exception;

public final class InvalidRentingPeriodException extends MyException{
    public InvalidRentingPeriodException(){
        super("Invalid Renting period");
    }
}